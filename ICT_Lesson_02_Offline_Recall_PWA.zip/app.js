const KEY="ictL2RecallStateV1", BACKUP="ictL2RecallBackupV1";
const fresh=()=>({schemaVersion:1,statuses:{},saved:[],folders:{},notes:{},timers:{},prefs:{}});
function load(){try{return Object.assign(fresh(),JSON.parse(localStorage.getItem(KEY)||"{}"))}catch{return fresh()}}
let state=load(),tab="questions",selectedFolder=null,deferredPrompt=null;
const $=s=>document.querySelector(s), esc=s=>String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));
function save(){localStorage.setItem(KEY,JSON.stringify(state));stats()}
function stats(){let k=Object.values(state.statuses).filter(x=>x==="known").length,r=Object.values(state.statuses).filter(x=>x==="review").length,t=QUESTIONS.length;$("#total").textContent=t;$("#known").textContent=k;$("#review").textContent=r;$("#remaining").textContent=t-k;let p=t?Math.round(k/t*100):0;$("#bar").style.width=p+"%";$("#pct").textContent=`${p}% සම්පූර්ණයි`}
function filtered(base){let s=$("#search").value.trim().toLowerCase(),sec=$("#section").value;return base.filter(q=>(!sec||q.section===sec)&&(!s||(q.q+" "+q.topic+" "+q.answer+" "+q.memory).toLowerCase().includes(s)))}
function card(q){let st=state.statuses[q.id];return `<article class="card" data-open="${q.id}"><span class="num">${q.n}</span><div><h3>${esc(q.q)}</h3><div class="meta">${q.section} • ${esc(q.topic)}</div><div class="badges">${st==="known"?'<span class="badge">✅ දන්නවා</span>':st==="review"?'<span class="badge">🔁 නැවත බලන්න</span>':""}</div></div><button class="star" data-star="${q.id}" aria-label="සුරකින්න">${state.saved.includes(q.id)?"★":"☆"}</button></article>`}
function render(){
 document.querySelectorAll("nav button").forEach(b=>b.classList.toggle("active",b.dataset.tab===tab));
 let c=$("#content"),base=QUESTIONS;
 if(tab==="saved")base=QUESTIONS.filter(q=>state.saved.includes(q.id));
 if(tab==="folders"){
   if(selectedFolder){
    let ids=selectedFolder==="known"?Object.keys(state.statuses).filter(id=>state.statuses[id]==="known"):selectedFolder==="review"?Object.keys(state.statuses).filter(id=>state.statuses[id]==="review"):(state.folders[selectedFolder]?.questionIds||[]);
    base=QUESTIONS.filter(q=>ids.includes(q.id)); c.innerHTML=`<div class="utility"><button class="primary" id="backFolders">← ෆෝල්ඩර්</button>${!["known","review"].includes(selectedFolder)?'<button class="danger" id="deleteFolder">🗑️ ෆෝල්ඩරය මකන්න</button>':""}</div>`+filtered(base).map(card).join(""); bindCards(); $("#backFolders").onclick=()=>{selectedFolder=null;render()}; if($("#deleteFolder"))$("#deleteFolder").onclick=deleteFolder; return;
   }
   let custom=Object.entries(state.folders).map(([id,f])=>`<div class="folder" data-folder="${id}"><h3>📁 ${esc(f.name)}</h3><span>${f.questionIds.length} ප්‍රශ්න</span></div>`).join("");
   c.innerHTML=`<div class="utility"><button class="primary" id="newFolder">＋ නව ෆෝල්ඩරයක්</button><button id="backup">💾 උපස්ථය</button><button id="restore">🛟 ප්‍රතිස්ථාපනය</button><button class="danger" id="reset">♻️ යළි සකසන්න</button></div><div class="folder-grid"><div class="folder" data-folder="known"><h3>✅ දන්නවා</h3><span>${Object.values(state.statuses).filter(x=>x==="known").length} ප්‍රශ්න</span></div><div class="folder" data-folder="review"><h3>🔁 නැවත බලන්න</h3><span>${Object.values(state.statuses).filter(x=>x==="review").length} ප්‍රශ්න</span></div>${custom}</div>`;
   c.querySelectorAll("[data-folder]").forEach(x=>x.onclick=()=>{selectedFolder=x.dataset.folder;render()});
   $("#newFolder").onclick=newFolder;$("#backup").onclick=backup;$("#restore").onclick=restore;$("#reset").onclick=reset; return;
 }
 c.innerHTML=filtered(base).map(card).join("")||'<div class="empty">ප්‍රශ්න හමු නොවීය.</div>'; bindCards()
}
function bindCards(){document.querySelectorAll("[data-open]").forEach(x=>x.onclick=e=>{if(e.target.closest("[data-star]"))return;openStudy(x.dataset.open)});document.querySelectorAll("[data-star]").forEach(x=>x.onclick=e=>{e.stopPropagation();toggleSave(x.dataset.star)})}
function toggleSave(id){state.saved=state.saved.includes(id)?state.saved.filter(x=>x!==id):[...state.saved,id];save();render()}
function openStudy(id){let q=QUESTIONS.find(x=>x.id===id); if(!q)return; let t=state.timers[id]; if(!t){t=state.timers[id]={unlockAt:Date.now()+60000};save()} $("#modal").classList.remove("hidden"); drawStudy(q); tick(q)}
let ticker;
function tick(q){clearInterval(ticker);ticker=setInterval(()=>{if($("#modal").classList.contains("hidden"))return clearInterval(ticker);drawStudy(q)},500)}
function drawStudy(q){let remain=Math.max(0,Math.ceil(((state.timers[q.id]?.unlockAt||0)-Date.now())/1000)), unlocked=remain<=0,st=state.statuses[q.id],folders=Object.entries(state.folders).map(([id,f])=>`<label><input type="checkbox" data-member="${id}" ${f.questionIds.includes(q.id)?"checked":""}> ${esc(f.name)}</label>`).join("");$("#study").innerHTML=`<small>${q.section} • ${esc(q.topic)}</small><h2>${esc(q.q)}</h2>${!unlocked?`<div class="timer">${remain}</div><p class="locked">🔒 තත්පර 60ක් ඔබේ මතකයෙන් පිළිතුර සිතා බලන්න.</p>`:`<button class="primary" id="reveal">පිළිතුර බලන්න</button><div id="answerBox"></div>`}<div class="actions"><button class="known ${st==="known"?"selected":""}" data-status="known">✅ දන්නවා</button><button class="review ${st==="review"?"selected":""}" data-status="review">🔁 නැවත බලන්න</button><button data-study-star>${state.saved.includes(q.id)?"★ සුරැකි":"☆ සුරකින්න"}</button></div><div class="note"><label>📝 මගේ සටහන</label><textarea id="note" rows="3" placeholder="ඔබේ මතක සටහන…">${esc(state.notes[q.id]||"")}</textarea></div><div class="folder-pick"><h3>📁 ෆෝල්ඩර්</h3>${folders||"<p class='meta'>තවම අභිරුචි ෆෝල්ඩර් නැත.</p>"}</div>`;
 if(unlocked)$("#reveal").onclick=()=>{$("#answerBox").innerHTML=`<div class="answer"><h3>සම්පූර්ණ පිළිතුර</h3><p>${esc(q.answer)}</p><div class="memory"><b>මතක පිළිතුර</b><p>${esc(q.memory)}</p></div><small>${esc(q.source)}</small></div>`};
 document.querySelectorAll("[data-status]").forEach(b=>b.onclick=()=>{let v=b.dataset.status;state.statuses[q.id]=state.statuses[q.id]===v?undefined:v;if(!state.statuses[q.id])delete state.statuses[q.id];save();drawStudy(q)});
 $("[data-study-star]").onclick=()=>{toggleSave(q.id);drawStudy(q)};$("#note").oninput=e=>{state.notes[q.id]=e.target.value;save()};
 document.querySelectorAll("[data-member]").forEach(x=>x.onchange=()=>{let a=state.folders[x.dataset.member].questionIds;a=x.checked?[...new Set([...a,q.id])]:a.filter(z=>z!==q.id);state.folders[x.dataset.member].questionIds=a;save()})
}
function newFolder(){let n=prompt("ෆෝල්ඩරයේ නම:");if(!n?.trim())return;let id="f_"+Date.now();state.folders[id]={name:n.trim(),questionIds:[]};save();render()}
function deleteFolder(){if(["known","review"].includes(selectedFolder))return;let f=state.folders[selectedFolder];if(confirm(`"${f.name}" ෆෝල්ඩරය මකන්නද? මුල් ප්‍රශ්න මැකෙන්නේ නැත.`)){delete state.folders[selectedFolder];selectedFolder=null;save();render()}}
function backup(){localStorage.setItem(BACKUP,JSON.stringify({timestamp:new Date().toISOString(),state}));alert("✅ උපස්ථය සාර්ථකව සුරැකිණි.")}
function restore(){let b=localStorage.getItem(BACKUP);if(!b)return alert("උපස්ථයක් හමු නොවීය.");if(confirm("නවතම උපස්ථයෙන් වත්මන් අධ්‍යයන තත්ත්වය ප්‍රතිස්ථාපනය කරන්නද?")){state=Object.assign(fresh(),JSON.parse(b).state||{});save();render();alert("✅ ප්‍රතිස්ථාපනය සම්පූර්ණයි.")}}
function reset(){if(confirm("⚠️ වත්මන් ප්‍රගතිය, සුරැකි, ෆෝල්ඩර් සහ සටහන් යළි සකසන්නද? උපස්ථය මැකෙන්නේ නැත.")&&confirm("මෙය ආපසු හැරවිය නොහැක. තහවුරු කරනවාද?")){localStorage.removeItem(KEY);state=fresh();save();selectedFolder=null;render()}}
$("#close").onclick=()=>{$("#modal").classList.add("hidden");clearInterval(ticker);render()};$("#modal").onclick=e=>{if(e.target===$("#modal"))$("#close").click()};
document.querySelectorAll("nav button").forEach(b=>b.onclick=()=>{tab=b.dataset.tab;selectedFolder=null;render()});$("#search").oninput=render;$("#section").onchange=render;
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;$("#installBtn").hidden=false});$("#installBtn").onclick=async()=>{if(deferredPrompt){deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;$("#installBtn").hidden=true}};
if("serviceWorker"in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("sw.js"));
stats();render();