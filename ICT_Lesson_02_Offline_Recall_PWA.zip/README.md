# A/L ICT පාඩම 02 — Offline Recall PWA

Mobile-first, installable offline study app for A/L ICT Lesson 02.

## Included
- 64 source-grounded core recall questions in Teacher's Guide 2.1–2.4 order
- 60-second persistent active-recall lock
- Full + memory answers
- Known / Review mutually-exclusive status
- Saved questions and custom folders
- Personal notes
- Backup / restore / reset (backup survives reset)
- Sinhala search and section filters
- LocalStorage persistence
- PWA manifest + service worker + 192/512 icons

## Run
Serve this folder with any static HTTP server. Service workers do not run from `file://`.

## Data safety
State uses versioned key `ictL2RecallStateV1`; backup is stored separately in `ictL2RecallBackupV1`.
